document.addEventListener("DOMContentLoaded", () => {
  chrome.tabs.create({ url: "chrome://newtab" });
});
